var valorEmGaleao = 35;
var cotacaoDoGaleao = 5.32;
var viajante = "Bem vindo querido viajante, a sua viagem para outro universo esta começando";

alert(viajante);

var valorEmReal= valorEmGaleao * cotacaoDoGaleao;
valorEmReal = valorEmReal.toFixed(2);

alert(" lembre-se, o valor do Galeão em real é R$ " + valorEmReal);


var anosLuz = 9500000000000;
var distanciaBuracoNegro = 1600;
var valorEmKm = anosLuz * distanciaBuracoNegro;

alert("a distancia da nossa viagem é de " + valorEmKm + "Km. Boa viagem");


